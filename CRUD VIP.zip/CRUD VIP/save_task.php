<?php

include('db.php');

if (isset($_POST['Guardar'])) {
  $Guia = $_POST['Guia'];
  $Cliente = $_POST['Cliente'];
    $Correo = $_POST['Correo'];
     $Fecha = $_POST['Fecha'];
      $Peso = $_POST['Peso'];
       $Entrega = $_POST['Entrega'];
  $query = "INSERT INTO Paquetes(Guia,Cliente,Correo,Fecha,Peso,Entrega)VALUES ('$Guia','Cliente','$Correo','$Fecha','$Peso','$Entrega')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Guardado';
  $_SESSION['message_type'] = 'success';
  header('Location: index.php');

}

?>

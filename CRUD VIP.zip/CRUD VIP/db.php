<?php
session_start();

$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'chh'
) or die(mysqli_erro($mysqli));

?>

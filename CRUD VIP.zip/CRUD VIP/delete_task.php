<?php

include("db.php");

if(isset($_GET['Guia'])) {
  $Guia = $_GET['Guia'];
  $query = "DELETE FROM cch WHERE Guia = $Guia";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Removed Successfully';
  $_SESSION['message_type'] = 'danger';
  header('Location: index.php');
}

?>
